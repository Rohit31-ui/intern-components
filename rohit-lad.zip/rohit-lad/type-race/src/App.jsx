import React, { useState, useEffect } from "react";
import InputBox from "./components/InputBox";
import SentenceDisplay from "./components/SentenceDisplay";
import ResultDisplay from "./components/ResultDisplay";

const App = () => {
  //sample sentece data for typing test
  const sentences = [
    "The quick brown fox jumps over the lazy dog.",
    "Typing is a valuable skill for developers.",
    "React makes UI development enjoyable.",
    "Practice makes perfect in coding.",
  ];

  const [sentence, setSentence] = useState("");
  const [userInput, setUserInput] = useState("");
  const [startTime, setStartTime] = useState(null);
  const [isFinished, setIsFinished] = useState(false);
  const [takenTime, setTakenTime] = useState(0);
  const [isFailed, setIsFailed] = useState(false);

  // Pick a random sentence on first load
  useEffect(() => {
    const random = sentences[Math.floor(Math.random() * sentences.length)];
    setSentence(random);
  }, []);

  // Timer updates every second
  useEffect(() => {
    let timer;
    if (startTime && !isFinished && !isFailed) {
      timer = setInterval(() => {
        setTakenTime(Math.floor((Date.now() - startTime) / 1000));
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [startTime, isFinished, isFailed]);
  //to handle input changes typed by user
  const handleInputChange = (value) => {
    if (!startTime) setStartTime(Date.now());

    // Failure: input goes beyond length and doesn't match
    if (
      value.length > sentence.length &&
      !sentence.startsWith(value.trim())
    ) {
      setUserInput(value);
      setIsFailed(true);
      return;
    }

    setUserInput(value);

    if (value === sentence) {
      setIsFinished(true);
      setIsFailed(false);
    }
  };
  //to handle restart the test
  const handleRestart = () => {
    const random = sentences[Math.floor(Math.random() * sentences.length)];
    setSentence(random);
    setUserInput("");
    setStartTime(null);
    setIsFinished(false);
    setIsFailed(false);
    setTakenTime(0);
  };

  return (

    <div className="max-w-3xl mx-auto mt-10 p-6 text-center font-medium rounded-xl shadow-lg">
      {/* heading */}
      <h1 className="text-3xl font-extrabold mb-4 text-blue-800">
         Typing Race Game - where typing speed gets improved
      </h1>
      
      {/* to display timer */}
      {startTime && !isFinished && !isFailed && (
        <p className="text-lg mb-4 text-gray-800 font-semibold">
           Time taken: <span className="text-blue-700">{takenTime}s</span>
        </p>
      )}

      <h2 className="text-left mt-4  text-sm">Type below given sentence to check accuracy</h2>
      {/* sentence for typing */}
      <SentenceDisplay sentence={sentence} userInput={userInput} />
      {/* to take input user */}
      <InputBox
        userInput={userInput}
        onChange={handleInputChange}
        isDisabled={isFinished || isFailed}
      />
      {/* to display result */}
      <ResultDisplay
        isFinished={isFinished}
        sentence={sentence}
        userInput={userInput}
        takenTime={takenTime}
      />
      {/* in case for failed handling */}
      {isFailed && !isFinished && (
        <div className="mt-4 text-left bg-red-100 border border-red-400 p-4 rounded text-red-700 shadow-sm">
          <p className="font-bold text-lg"> Accuracy: 0%</p>
          <p className="text-sm mt-1">
            You typed too many incorrect characters. Please try again.
          </p>
        </div>
      )}
        {/* to restart */}
      {(isFinished || isFailed) && (
        <button
          onClick={handleRestart}
          className="mt-6 px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow transition-all"
        >
          🔁 Restart Game
        </button>
      )}
    </div>
  );
};

export default App;
