import React from 'react'

const InputBox = ({userInput,onChange,isDisabled}) => {
  return (
    <div>
      <textarea rows={3}
      className='w-full p-3 border rounded resize-none font-mono'
      placeholder='start typing here.....'
      value={userInput}
      onChange={(e)=>onChange(e.target.value)}
      disabled={isDisabled}
      autoFocus></textarea>
    </div>
  )
}

export default InputBox
