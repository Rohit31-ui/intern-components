import React from 'react'

const SentenceDisplay = ({sentence,userInput}) => {
    //display sentence
    const getCharClass = (char, index) => {
    if (!userInput[index]) return 'text-gray-400';
    if (userInput[index] === char) return 'text-green-600';
    return 'text-red-600';
  };
 
    return (
    <div className='text-left mb-4 p-4 rounded bg-gray-100 mt-6 leading-relaxed'>
      {sentence.split('').map((char, idx) => (
        <span key={idx} className={getCharClass(char, idx)}>
          {char}
        </span>
      ))}
    </div>
  )
}

export default SentenceDisplay
