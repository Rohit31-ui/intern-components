import React from 'react'

const ResultDisplay = ({isFinished,sentence,userInput,takenTime}) => {
  if (!isFinished) return null;
    //get words from sentence
  const words = sentence.trim().split(/\s+/).length;
  //speed of word per second
  const wps = (words / takenTime).toFixed(2); 
    //calculate correctenes
  const correctChars = userInput
    .split('')
    .filter((char, i) => char === sentence[i]).length;
    //calculate accuracy
  const accuracy = Math.round((correctChars / sentence.length) * 100) || 0;

  return (
    <div className="mt-4 text-left bg-green-50 border p-4 rounded">
      <p><strong>Time Taken:</strong> {takenTime} seconds</p>
      <p><strong>WPS (Words Per Second):</strong> {wps}</p>
      <p><strong>Accuracy:</strong> {accuracy}%</p>
    </div>
  )};

export default ResultDisplay
